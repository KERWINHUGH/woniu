#include "anime_homepage.h"
#include "dial_class/Knob_page.h"
#include "Login_interface/responsive_form.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Responsive_form w;
    //Knob_page w;
    w.show();
    return a.exec();
}
