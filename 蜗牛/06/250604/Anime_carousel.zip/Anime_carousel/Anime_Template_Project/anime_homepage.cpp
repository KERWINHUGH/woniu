﻿#include "anime_homepage.h"

Anime_Homepage::Anime_Homepage(QWidget *parent) : QWidget(parent)
{
}

Anime_Homepage::~Anime_Homepage()
{
}
