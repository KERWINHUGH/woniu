#include "easycounter.h"

#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    EasyCounter w;
    w.show();
    return a.exec();
}
