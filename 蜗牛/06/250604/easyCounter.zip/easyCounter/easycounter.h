#ifndef EASYCOUNTER_H
#define EASYCOUNTER_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class EasyCounter;
}
QT_END_NAMESPACE

class EasyCounter : public QWidget {
    Q_OBJECT

public:
    EasyCounter(QWidget *parent = nullptr);
    ~EasyCounter();

private slots:
    void onIncreaseClicked();    // 增加计数
    void onDecreaseClicked();    // 减少计数
    void onResetClicked();  // 重置计数

private:
    Ui::EasyCounter *ui;
    int m_nCount;
};
#endif // EASYCOUNTER_H
