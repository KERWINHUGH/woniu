#include "easycounter.h"
#include "./ui_easycounter.h"

EasyCounter::EasyCounter(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::EasyCounter) {
    ui->setupUi(this);
    m_nCount = 0;
    ui->label->setNum(m_nCount);

    connect(ui->btnIncrease, &QPushButton::clicked, this, &EasyCounter::onIncreaseClicked);
    connect(ui->btnDecrease, &QPushButton::clicked, this, &EasyCounter::onDecreaseClicked);
    connect(ui->btnClear, &QPushButton::clicked, this, &EasyCounter::onResetClicked);
}

void EasyCounter::onIncreaseClicked() {
    qDebug() << "Increase";
    m_nCount++;
    ui->label->setNum(m_nCount);
}

void EasyCounter::onDecreaseClicked() {
    qDebug() << "Decrease";
    m_nCount--;
    if (m_nCount < 0) {
        m_nCount = 0;
    }
    ui->label->setNum(m_nCount);
}

void EasyCounter::onResetClicked() {
    qDebug() << "Reset";
    m_nCount = 0;
    ui->label->setNum(m_nCount);
}

EasyCounter::~EasyCounter() {
    delete ui;
}
