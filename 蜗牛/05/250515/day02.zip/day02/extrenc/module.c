#include "module.h"

void func1() {
	printf("hello world!\n");
}

int func2(int a, int b) {
	return a + b;
}
