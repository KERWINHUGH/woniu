// This setup is for the RP2040 processor only when used with 8-bit parallel displays
// See SetupX_Template.h for all options available
//自己随便写一个，建议写成0
#define USER_SETUP_ID 0

////////////////////////////////////////////////////////////////////////////////////////////
// 通信方式： 8位并口
////////////////////////////////////////////////////////////////////////////////////////////
#define TFT_PARALLEL_8_BIT

////////////////////////////////////////////////////////////////////////////////////////////
// 选择要通信的显示芯片型号
////////////////////////////////////////////////////////////////////////////////////////////
#define ST7796_DRIVER

#define TFT_CS    10  //片选
#define TFT_DC    9   //数据指令
#define TFT_RST   14  //重置

#define TFT_WR    15  //写
#define TFT_RD    6   //读

//以下8个是并口数据线
#define TFT_D0   1  
#define TFT_D1   2 
#define TFT_D2   7
#define TFT_D3   8
#define TFT_D4   3
#define TFT_D5   18
#define TFT_D6   17
#define TFT_D7   16

#define TFT_BL   4				// 哪个引脚控制背光,单片机的4-屏幕33
#define TFT_BACKLIGHT_ON LOW	//低电平点亮
 
//定义要使用的显示模式
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define LOAD_FONT6
#define LOAD_FONT7
#define LOAD_FONT8
#define LOAD_GFXFF

#define SMOOTH_FONT