#ifndef __IC_H
#define __IC_H
#include "OLED.h"
#include "Serial.h"
void Sent_ICode(uint8_t *arr);
#endif

