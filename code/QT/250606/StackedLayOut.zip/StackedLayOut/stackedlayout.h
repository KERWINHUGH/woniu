#ifndef STACKEDLAYOUT_H
#define STACKEDLAYOUT_H

#include <QWidget>
#include "a.h"
#include "b.h"
#include "c.h"
#include "QStackedLayout"


QT_BEGIN_NAMESPACE
namespace Ui { class stackedLayout; }
QT_END_NAMESPACE

class stackedLayout : public QWidget
{
    Q_OBJECT

public:
    stackedLayout(QWidget *parent = nullptr);
    ~stackedLayout();

private:
    Ui::stackedLayout *ui;

    A* m_pA;
    B* m_pB;
    C* m_pC;

    QStackedLayout *m_pQStackedLayout;

};
#endif // STACKEDLAYOUT_H
