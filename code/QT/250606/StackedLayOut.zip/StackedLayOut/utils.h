#ifndef UTILS_H
#define UTILS_H


#define INDEX_A  0
#define INDEX_B  1
#define INDEX_C  2


#endif // UTILS_H
