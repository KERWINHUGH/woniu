#ifndef _KEY_H
#define _KEY_H

void Key_Init(void);
uint8_t getKeyPressNum(void);


#endif
