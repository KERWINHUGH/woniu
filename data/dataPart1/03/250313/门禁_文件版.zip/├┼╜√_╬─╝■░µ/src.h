extern int role;
extern char username[20];
int login();
int addUser();
void displayAllUsersInfo();
void displayUserInfo();
int deleteUser();
int modifyUserInfo(int choice);