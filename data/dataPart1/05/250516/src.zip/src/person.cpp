#include "person.h"

void Person::init(const std::string name, int age) {
	m_Name = name;
	m_nAge = age;
}

std::string Person::getName() const {
	return m_Name;
}

int Person::getAge() const {
	return m_nAge;
}

void Person::setName(std::string name) {
	m_Name = name;
}

void Person::setAge(int age) {
	if (age <= 0 || age > 100) {
		std::cout << "out of range" << std::endl;
		return;
	}
	m_nAge = age;
}

void Person::printName() {
	std::cout << "姓名为：" << getName() << std::endl;
}

void Person::printAge() {
	std::cout << "年龄为：" << getAge() << std::endl;
}






