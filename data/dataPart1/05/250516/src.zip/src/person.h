#ifndef PERSON_H_
#define PERSON_H_

#include <iostream>

class Person {
private:
	std::string m_Name;
	int m_nAge;

public:
	void init(const std::string, int);

	std::string getName() const;
	int getAge() const;

	void setName(const std::string name);
	void setAge(int age);

	void printName();
	void printAge();
};

#endif
