/***********************************************************************************
# File Name:    main.cpp
# Author:       ciyeer
# Mail:         ciyeer@outlook.com 
# Created Time: Fri May 16 15:50:46 2025
 **********************************************************************************/

#include <iostream>
#include "person.h"
using namespace std;

int main(int argc, char *argv[]) {
	Person p;
	p.init("Zhangsan", 17);
	p.printName();
	p.printAge();

	p.setName("Lisi");
	p.setAge(16);
	p.printName();
	p.printAge();

    return 0;
}
