#include "login.h"
#include "ui_login.h"

Login::Login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Login) {
    ui->setupUi(this);
    this->setWindowTitle("zhangsan");
    this->setWindowIcon(QIcon(":/qrc/logo.png"));
}

Login::~Login() {
    delete ui;
}
