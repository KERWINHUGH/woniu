#include "widget.h"
#include "./ui_widget.h"
#include <QRect>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget) {
    ui->setupUi(this);
    this->setWindowTitle("zhangsan");
}

void Widget::onPositionClicked() {
    QRect rect = this->frameGeometry();
    qDebug() << "左上角: " << rect.topLeft()
             << "右上角: " << rect.topRight()
             << "左下角: " << rect.bottomLeft()
             << "右下角: " << rect.bottomRight()
             << "宽度: " << rect.width()
             << "高度: " << rect.height();
}

void Widget::mousePressEvent(QMouseEvent *event) {
    onPositionClicked();
}

Widget::~Widget() {
    delete ui;
}
